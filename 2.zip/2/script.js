/* ============================================
   VELOCITAS — Premium JavaScript
   Cursor · Navbar · Scroll Reveal
   ============================================ */

(function () {
    "use strict";

    // ==========================================
    // 1. CUSTOM CURSOR
    // ==========================================
    const cursor = document.getElementById("cursor");
    const follower = document.getElementById("cursor-follower");

    if (cursor && follower && window.innerWidth > 768) {
        let mouseX = 0, mouseY = 0;
        let followerX = 0, followerY = 0;

        document.addEventListener("mousemove", (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            cursor.style.left = mouseX + "px";
            cursor.style.top = mouseY + "px";
        });

        // Smooth follower with rAF
        function animateFollower() {
            followerX += (mouseX - followerX) * 0.12;
            followerY += (mouseY - followerY) * 0.12;
            follower.style.left = followerX + "px";
            follower.style.top = followerY + "px";
            requestAnimationFrame(animateFollower);
        }
        animateFollower();

        // Hover enlargement on interactive elements
        const interactives = document.querySelectorAll("a, button, summary, .brand-card, .tech-card, .term-card");
        interactives.forEach((el) => {
            el.addEventListener("mouseenter", () => {
                cursor.style.transform = "translate(-50%, -50%) scale(2)";
                follower.style.transform = "translate(-50%, -50%) scale(1.5)";
                follower.style.borderColor = "rgba(212, 175, 55, 0.5)";
            });
            el.addEventListener("mouseleave", () => {
                cursor.style.transform = "translate(-50%, -50%) scale(1)";
                follower.style.transform = "translate(-50%, -50%) scale(1)";
                follower.style.borderColor = "rgba(212, 175, 55, 0.25)";
            });
        });
    }

    // ==========================================
    // 2. STICKY NAVBAR — scroll effect
    // ==========================================
    const navbar = document.getElementById("navbar");
    if (navbar) {
        window.addEventListener("scroll", () => {
            if (window.scrollY > 60) {
                navbar.classList.add("scrolled");
            } else {
                navbar.classList.remove("scrolled");
            }
        }, { passive: true });
    }

    // ==========================================
    // 3. SCROLL REVEAL — Intersection Observer
    // ==========================================
    const revealTargets = document.querySelectorAll(
        ".brand-item, .tech-card, .term-card, .section-header"
    );

    const revealObserver = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.style.animationPlayState = "running";
                    revealObserver.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
    );

    revealTargets.forEach((el) => {
        // Pause animations initially; let observer trigger them
        el.style.animationPlayState = "paused";
        revealObserver.observe(el);
    });

    // ==========================================
    // 4. SMOOTH SCROLL for anchor links
    // ==========================================
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
        anchor.addEventListener("click", (e) => {
            e.preventDefault();
            const target = document.querySelector(anchor.getAttribute("href"));
            if (target) {
                const offset = 80; // navbar height
                const top = target.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top, behavior: "smooth" });
            }
        });
    });

    // ==========================================
    // 5. ACCORDION — close others when one opens
    // ==========================================
    const accordions = document.querySelectorAll(".brand-accordion");
    accordions.forEach((acc) => {
        acc.addEventListener("toggle", () => {
            if (acc.open) {
                accordions.forEach((other) => {
                    if (other !== acc && other.open) {
                        other.open = false;
                    }
                });
            }
        });
    });

})();